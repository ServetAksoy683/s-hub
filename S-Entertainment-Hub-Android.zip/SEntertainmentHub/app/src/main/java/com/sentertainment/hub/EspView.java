package com.sentertainment.hub;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class EspView extends View {
    static class Box { float x, y, w, h; String label; }
    private volatile List<Box> boxes = new ArrayList<>();
    private final List<Box> pending = new ArrayList<>();
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

    public EspView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2 * d);
        stroke.setColor(0xFF00F2FE);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(12 * d);
        text.setShadowLayer(3, 0, 0, 0xFF000000);
    }

    void add(float x, float y, float w, float h, String label) {
        Box b = new Box(); b.x = x; b.y = y; b.w = w; b.h = h; b.label = label;
        pending.add(b);
    }
    void publish() { boxes = new ArrayList<>(pending); pending.clear(); postInvalidate(); }
    void clearAll() { pending.clear(); boxes = new ArrayList<>(); postInvalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        for (Box b : boxes) {
            c.drawRect(b.x, b.y, b.x + b.w, b.y + b.h, stroke);
            if (b.label != null && !b.label.isEmpty()) c.drawText(b.label, b.x, b.y - 6, text);
        }
    }
}
