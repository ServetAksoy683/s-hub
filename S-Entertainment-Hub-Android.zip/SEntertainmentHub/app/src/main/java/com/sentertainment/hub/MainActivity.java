package com.sentertainment.hub;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    class Bridge {
        @JavascriptInterface
        public boolean isMenuRunning() { return FloatingService.running; }

        @JavascriptInterface
        public void stopFloatingMenu() {
            runOnUiThread(() -> stopService(new Intent(MainActivity.this, FloatingService.class)));
        }

        @JavascriptInterface
        public void startFloatingMenu() {
            runOnUiThread(() -> {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "Üstte gösterme iznini ver", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } else if (!FloatingService.hasUsageAccess(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "S-Entertainment Hub için 'Kullanım erişimi' iznini ver", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } else {
                    startService(new Intent(MainActivity.this, FloatingService.class));
                    openGame();
                }
            });
        }
    }

    /** assets/game_package.txt içindeki paket adına sahip oyunu açar */
    private void openGame() {
        try {
            java.io.InputStream in = getAssets().open("game_package.txt");
            byte[] b = new byte[256];
            int n = in.read(b);
            in.close();
            String pkg = new String(b, 0, Math.max(n, 0)).trim();
            Intent li = pkg.isEmpty() ? null : getPackageManager().getLaunchIntentForPackage(pkg);
            if (li == null) {
                Toast.makeText(this, "Oyun bulunamadı. game_package.txt dosyasındaki paket adını kontrol et.", Toast.LENGTH_LONG).show();
                return;
            }
            webView.postDelayed(() -> startActivity(li), 500);
        } catch (Exception e) {
            Toast.makeText(this, "Oyun açılamadı", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
