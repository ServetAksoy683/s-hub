package com.sentertainment.hub;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class FloatingService extends Service {
    private WindowManager wm;
    private final Handler main = new Handler(Looper.getMainLooper());
    private float density;

    private EspView esp;
    private LuaManager lua;
    private ImageView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private FrameLayout menuRoot;
    private WebView web;
    private WindowManager.LayoutParams menuLp;
    private boolean bubbleShown, menuShown;

    @Override public IBinder onBind(Intent i) { return null; }

    private int dp(int v) { return Math.round(v * density); }

    private DisplayMetrics screen() { return getResources().getDisplayMetrics(); }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (bubble != null) return START_STICKY;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        density = screen().density;
        setupEsp();
        setupBubble();
        setupMenu();
        showBubble();
        return START_STICKY;
    }

    // ---------- ESP çizim katmanı (dokunmayı geçirir) ----------
    private void setupEsp() {
        esp = new EspView(this);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        wm.addView(esp, p);
        lua = new LuaManager(this, esp);
    }

    // ---------- Oxide logolu yüzen buton ----------
    @SuppressLint("ClickableViewAccessibility")
    private void setupBubble() {
        bubble = new ImageView(this);
        try {
            Bitmap bmp = BitmapFactory.decodeStream(getAssets().open("oxide_logo.jpg"));
            bubble.setImageBitmap(bmp);
        } catch (Exception e) { bubble.setBackgroundColor(0xFFD9412B); }
        bubble.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bubble.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setOval(0, 0, v.getWidth(), v.getHeight()); }
        });
        bubble.setClipToOutline(true);
        bubble.setElevation(dp(6));

        int size = dp(52);
        bubbleLp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = dp(16); bubbleLp.y = dp(160);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bubbleLp.x; sy = bubbleLp.y; tx = e.getRawX(); ty = e.getRawY(); moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) moved = true;
                        if (moved) {
                            bubbleLp.x = clamp(sx + (int) dx, 0, screen().widthPixels - bubbleLp.width);
                            bubbleLp.y = clamp(sy + (int) dy, 0, screen().heightPixels - bubbleLp.height);
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) openMenu();
                        return true;
                }
                return false;
            }
        });
    }

    // ---------- Menü penceresi (WebView + sürükleme tutacağı) ----------
    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    private void setupMenu() {
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "AndroidMenu");
        web.loadUrl("file:///android_asset/menu.html");

        menuRoot = new FrameLayout(this);
        menuRoot.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // Başlığın (kontrol butonları hariç) üstünde şeffaf sürükleme alanı
        View drag = new View(this);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-1, dp(72));
        dlp.leftMargin = dp(90);
        menuRoot.addView(drag, dlp);

        DisplayMetrics m = screen();
        int w = Math.min(dp(420), (int) (m.widthPixels * 0.9f));
        int h = Math.min(dp(520), (int) (m.heightPixels * 0.85f));
        menuLp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        menuLp.gravity = Gravity.TOP | Gravity.START;

        drag.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = menuLp.x; sy = menuLp.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        menuLp.x = clamp(sx + (int) (e.getRawX() - tx), 0, screen().widthPixels - menuLp.width);
                        menuLp.y = clamp(sy + (int) (e.getRawY() - ty), 0, screen().heightPixels - menuLp.height);
                        wm.updateViewLayout(menuRoot, menuLp);
                        return true;
                }
                return true;
            }
        });
    }

    private int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(v, Math.max(lo, hi))); }

    private void showBubble() { if (!bubbleShown) { wm.addView(bubble, bubbleLp); bubbleShown = true; } }
    private void hideBubble() { if (bubbleShown) { wm.removeView(bubble); bubbleShown = false; } }
    private void showMenu() { if (!menuShown) { wm.addView(menuRoot, menuLp); menuShown = true; } }
    private void hideMenu() { if (menuShown) { wm.removeView(menuRoot); menuShown = false; } }

    /** Menüyü butonun bulunduğu yerde aç */
    private void openMenu() {
        int cx = bubbleLp.x + bubbleLp.width / 2, cy = bubbleLp.y + bubbleLp.height / 2;
        menuLp.x = clamp(cx - menuLp.width / 2, 0, screen().widthPixels - menuLp.width);
        menuLp.y = clamp(cy - menuLp.height / 2, 0, screen().heightPixels - menuLp.height);
        hideBubble();
        showMenu();
    }

    // ---------- HTML -> Android köprüsü ----------
    class Bridge {
        @JavascriptInterface public void minimize() { main.post(() -> { hideMenu(); showBubble(); }); }
        @JavascriptInterface public void closeAll() { main.post(() -> stopSelf()); }
        @JavascriptInterface public void setFeature(String name, boolean on) { lua.setFeature(name, on); }
        @JavascriptInterface public void setSpeed(double v) { lua.setValue("Speed", v); }
    }

    @Override
    public void onDestroy() {
        if (lua != null) lua.shutdown();
        hideBubble(); hideMenu();
        if (esp != null) { wm.removeView(esp); esp = null; }
        if (web != null) { web.destroy(); web = null; }
        bubble = null;
        super.onDestroy();
    }
}
