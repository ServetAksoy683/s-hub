package com.sentertainment.hub;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

public class FloatingService extends Service {
    private WindowManager wm;
    private TextView bubble;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (bubble != null) return START_STICKY;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setText("S");
        bubble.setTextColor(0xFFFFFFFF);
        bubble.setTextSize(22);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundColor(0xFF0088FF);
        final WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                150, 150,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = 50; p.y = 300;

        bubble.setOnTouchListener(new android.view.View.OnTouchListener() {
            int sx, sy; float tx, ty; boolean moved;
            @Override public boolean onTouch(android.view.View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = p.x; sy = p.y; tx = e.getRawX(); ty = e.getRawY(); moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        p.x = sx + (int)(e.getRawX() - tx);
                        p.y = sy + (int)(e.getRawY() - ty);
                        moved = true;
                        wm.updateViewLayout(bubble, p); return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            // TODO: burada mod menü panelini aç/kapat
                        }
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, p);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (bubble != null) wm.removeView(bubble);
        super.onDestroy();
    }
}
