package com.sentertainment.hub;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.OneArgFunction;
import org.luaj.vm2.lib.VarArgFunction;
import org.luaj.vm2.lib.ZeroArgFunction;
import org.luaj.vm2.lib.jse.JsePlatform;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/** Şalter adı -> assets/lua/<dosya>.lua eşlemesi ve çalıştırıcı. */
public class LuaManager {
    private static final String TAG = "OxideLua";
    private static final Map<String, String> FILES = new HashMap<>();
    static {
        FILES.put("ESP", "esp.lua");
        FILES.put("Aimlock", "aimlock.lua");
        FILES.put("Mermi", "ammo.lua");
        FILES.put("Speed", "speed.lua");
    }

    private final Context ctx;
    private final EspView esp;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor();
    private final Map<String, Globals> envs = new HashMap<>();
    private final Map<String, ScheduledFuture<?>> ticks = new HashMap<>();

    public LuaManager(Context ctx, EspView esp) { this.ctx = ctx; this.esp = esp; }

    public void setFeature(final String name, final boolean on) {
        ex.submit(() -> {
            try {
                Globals g = env(name);
                if (g == null) return;
                if (on) {
                    call(g, "onEnable");
                    if (g.get("onTick").isfunction() && !ticks.containsKey(name)) {
                        ticks.put(name, ex.scheduleWithFixedDelay(() -> {
                            try { call(g, "onTick"); } catch (Throwable t) { Log.e(TAG, name + " onTick: " + t); }
                        }, 0, 33, TimeUnit.MILLISECONDS));
                    }
                } else {
                    ScheduledFuture<?> f = ticks.remove(name);
                    if (f != null) f.cancel(false);
                    call(g, "onDisable");
                }
            } catch (Throwable t) {
                Log.e(TAG, name + ": " + t);
                toast("Lua hata (" + name + "): " + t.getMessage());
            }
        });
    }

    public void setValue(final String name, final double v) {
        ex.submit(() -> {
            try {
                Globals g = envs.get(name);
                if (g != null && g.get("onValue").isfunction()) g.get("onValue").call(LuaValue.valueOf(v));
            } catch (Throwable t) { Log.e(TAG, name + " onValue: " + t); }
        });
    }

    public void shutdown() { ex.shutdownNow(); }

    private void call(Globals g, String fn) {
        LuaValue f = g.get(fn);
        if (f.isfunction()) f.call();
    }

    private Globals env(String name) throws Exception {
        Globals g = envs.get(name);
        if (g != null) return g;
        String file = FILES.get(name);
        if (file == null) { Log.w(TAG, "Bilinmeyen özellik: " + name); return null; }
        String src = read("lua/" + file);
        g = JsePlatform.standardGlobals();
        install(g, name);
        g.load(src, file).call();
        envs.put(name, g);
        return g;
    }

    private String read(String path) throws Exception {
        InputStream in = ctx.getAssets().open(path);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[4096]; int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        return o.toString("UTF-8");
    }

    private void toast(final String m) {
        main.post(() -> Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show());
    }

    /** Lua'dan çağrılabilecek fonksiyonlar */
    private void install(Globals g, final String feature) {
        g.set("log", new OneArgFunction() {
            public LuaValue call(LuaValue a) { Log.d(TAG, feature + ": " + a.tojstring()); return NIL; }
        });
        g.set("toast", new OneArgFunction() {
            public LuaValue call(LuaValue a) { toast(a.tojstring()); return NIL; }
        });
        g.set("screenW", new ZeroArgFunction() {
            public LuaValue call() { return valueOf(esp.getWidth()); }
        });
        g.set("screenH", new ZeroArgFunction() {
            public LuaValue call() { return valueOf(esp.getHeight()); }
        });
        g.set("millis", new ZeroArgFunction() {
            public LuaValue call() { return valueOf((double) System.currentTimeMillis()); }
        });
        LuaTable t = new LuaTable();
        t.set("clear", new ZeroArgFunction() {
            public LuaValue call() { esp.clearAll(); return NIL; }
        });
        t.set("show", new ZeroArgFunction() {
            public LuaValue call() { esp.publish(); return NIL; }
        });
        t.set("box", new VarArgFunction() {
            public Varargs invoke(Varargs a) {
                esp.add((float) a.optdouble(1, 0), (float) a.optdouble(2, 0),
                        (float) a.optdouble(3, 0), (float) a.optdouble(4, 0), a.optjstring(5, ""));
                return NONE;
            }
        });
        g.set("esp", t);
    }
}
