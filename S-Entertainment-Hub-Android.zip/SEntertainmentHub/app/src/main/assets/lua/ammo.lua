-- MERMİ HİLESİ: şalter açılınca onEnable, kapanınca onDisable çalışır.
function onEnable()
  log("Mermi açıldı")
  -- >>> KODUNU BURAYA YAZ <<<
end

function onDisable()
  log("Mermi kapandı")
  -- >>> KAPATMA KODUNU BURAYA YAZ <<<
end
