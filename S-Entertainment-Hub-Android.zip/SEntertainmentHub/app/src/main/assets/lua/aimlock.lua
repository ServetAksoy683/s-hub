-- AIMLOCK: şalter açılınca onEnable, kapanınca onDisable çalışır.
-- onTick yazarsan açıkken sürekli çalışır.
function onEnable()
  log("Aimlock açıldı")
  -- >>> KODUNU BURAYA YAZ <<<
end

function onDisable()
  log("Aimlock kapandı")
  -- >>> KAPATMA KODUNU BURAYA YAZ <<<
end
