-- =====================================================
--  FEIGN ROLE ESP  (şalter AÇILINCA onEnable, KAPANINCA onDisable)
--  onTick varsa şalter açıkken saniyede ~30 kez çalışır
-- =====================================================
-- Kullanılabilir fonksiyonlar:
--   log("yazı")            -> logcat'e yazar
--   toast("yazı")          -> ekranda mesaj gösterir
--   screenW(), screenH()   -> ekran boyutu (piksel)
--   millis()               -> şu anki zaman (ms)
--   esp.box(x, y, w, h, "etiket")  -> kutu ekler
--   esp.show()             -> eklenen kutuları ekrana çizer
--   esp.clear()            -> tüm kutuları siler

local t = 0

-- >>>>>>>>>>  BURAYI KENDİ KODUNLA DEĞİŞTİR  <<<<<<<<<<
-- Hedeflerin listesini döndür. Şu an sadece DENEME kutusu üretir.
function getTargets()
  local w, h = screenW(), screenH()
  return {
    { x = w/2 + math.cos(t) * 250, y = h/2 + math.sin(t) * 120,
      w = 140, h = 220, name = "ROLE ESP TEST" }
  }
end
-- >>>>>>>>>>  DEĞİŞTİRME ALANI BİTTİ  <<<<<<<<<<

function onEnable()
  log("ROLE ESP açıldı")
  toast("ROLE ESP AÇIK")
end

function onTick()
  t = t + 0.05
  for _, tg in ipairs(getTargets()) do
    esp.box(tg.x - tg.w/2, tg.y - tg.h/2, tg.w, tg.h, tg.name)
  end
  esp.show()
end

function onDisable()
  esp.clear()
  log("ROLE ESP kapandı")
  toast("ROLE ESP KAPALI")
end
