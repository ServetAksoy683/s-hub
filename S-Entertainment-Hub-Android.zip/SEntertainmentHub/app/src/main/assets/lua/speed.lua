-- HIZ ARTIRICI: onValue(v) slider her oynadığında çalışır (1.0 - 10.0)
local mult = 2.0

function onEnable()
  log("Hız açıldı, çarpan: " .. mult)
  -- >>> KODUNU BURAYA YAZ <<<
end

function onValue(v)
  mult = v
  log("Yeni hız çarpanı: " .. v)
  -- >>> ÇARPANI UYGULAYAN KODU BURAYA YAZ <<<
end

function onDisable()
  log("Hız kapandı")
  -- >>> KAPATMA KODUNU BURAYA YAZ <<<
end
