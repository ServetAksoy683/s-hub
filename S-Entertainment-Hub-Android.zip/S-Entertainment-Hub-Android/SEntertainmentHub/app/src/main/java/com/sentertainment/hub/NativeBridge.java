package com.sentertainment.hub;

import android.util.Log;

public class NativeBridge {
    private static final String TAG = "NativeBridge";
    private static boolean loaded = false;

    static {
        try {
            System.loadLibrary("feign_native");
            loaded = true;
            Log.i(TAG, "Native library loaded successfully");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Native library failed to load: " + e.getMessage());
            loaded = false;
        }
    }

    public static native String getNativeVersion();
    public static native int nativeAdd(int a, int b);

    public static boolean isLoaded() {
        return loaded;
    }
}