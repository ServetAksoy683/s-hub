#include <jni.h>
#include <string>
#include <android/log.h>

#define LOG_TAG "FeignNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

// Paket adı: com.sentertainment.hub
// JNI kuralı: noktalar alt çizgiye dönüşür → com_sentertainment_hub

extern "C" JNIEXPORT jstring JNICALL
Java_com_sentertainment_hub_NativeBridge_getNativeVersion(
        JNIEnv* env, jobject /* this */) {
    std::string version = "Feign Native v1.0.0";
    LOGI("Native version requested");
    return env->NewStringUTF(version.c_str());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_sentertainment_hub_NativeBridge_nativeAdd(
        JNIEnv* env, jobject /* this */, jint a, jint b) {
    LOGI("nativeAdd called");
    return a + b;
}